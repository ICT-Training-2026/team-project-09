package com.example.demo.controller;

import org.springframework.stereotype.Controller;

@Controller
public class TopController {

//    @GetMapping("/")
//    public String top() {
//        return "top";
//    }
	
}
